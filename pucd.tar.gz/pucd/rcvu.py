#!/usr/bin/python3
import sys
import time
import subprocess
import json
import config
from socket import socket, AF_INET, SOCK_DGRAM, SOL_SOCKET, SO_BROADCAST
service_flag = 1

def main():
  getServiceOption()
  s = socket(AF_INET, SOCK_DGRAM)
  s.bind((config.HOST, config.PORT))
  while True:
    msg, address = s.recvfrom(config.BFSZ)
    receiveUDP(msg, address)
  s.close()

def writeJson(port, fr, res):
  str = {"port": port, "framerate": fr, "resolution": res }
  with open(config.PATH_MOMO + 'html/momo.json', 'w') as f:
    json.dump(str, f, ensure_ascii=False)

def getServiceOption():
  f = open(config.PATH_SERVICE, 'r')
  fr = 0
  res = ''
  port = 0
  for line in f:
    data = line.split(' ')
    if data[0].find('ExecStart') == 0:
      i = 0
      for item in data:
        if item == "--framerate":
          fr = int(data[i + 1])
        elif item == "--resolution":
          res = data[i + 1]
        elif item == "--port":
          port = int(data[i + 1])
        i += 1
      break
  f.close()
  writeJson(port, fr, res)

def stopMomoService():
    subprocess.run(["sudo", "systemctl", "stop", "momo.service"] , encoding='utf-8',stdout=subprocess.PIPE)

def stopMomo():
    subprocess.run(["sudo", "pkill", "-KILL", "-f", "momo"] , encoding='utf-8',stdout=subprocess.PIPE)

def startMomo(port, fr, res):
    path = r"" + config.PATH_MOMO
    momo = config.MOMO + " --framerate " + str(fr) + " --resolution " + res + " --fixed-resolution --port " + str(port) + " test"
    proc = subprocess.Popen(momo, cwd=path, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    return proc.pid

def receiveUDP(msg, address):
    global service_flag
    dg = (msg.decode('utf-8')).split(config.SEPARATOR)
    if dg[0] == config.KEYWORD:
        if service_flag == 1:
          stopMomoService()
          service_flag = 0
          time.sleep(1)
        stopMomo()
        time.sleep(2)
        startMomo(dg[1], dg[2], dg[3])
        time.sleep(1)
        writeJson(dg[1], dg[2], dg[3])

if __name__ == "__main__":
  main()
