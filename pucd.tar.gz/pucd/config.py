HOST = ''
PORT = 50001
BFSZ = 65535
KEYWORD = 'MOMO'
SEPARATOR = ','
MOMO = '/usr/share/momo-19.11.0_raspbian-buster_armv7/momo'
PATH_MOMO = '/usr/share/momo-19.11.0_raspbian-buster_armv7/'
PATH_SERVICE = '/etc/systemd/system/momo.service'
